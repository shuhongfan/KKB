package com.kkb.core.handler;

public class RouterStatementHandler implements StatementHandler{
}
