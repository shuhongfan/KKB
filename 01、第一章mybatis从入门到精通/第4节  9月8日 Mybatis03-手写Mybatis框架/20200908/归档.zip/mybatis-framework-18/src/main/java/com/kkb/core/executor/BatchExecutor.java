package com.kkb.core.executor;

public class BatchExecutor {
}
