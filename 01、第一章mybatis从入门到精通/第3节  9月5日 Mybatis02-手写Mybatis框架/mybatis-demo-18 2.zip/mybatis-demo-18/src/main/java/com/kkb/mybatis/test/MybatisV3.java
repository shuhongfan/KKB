package com.kkb.mybatis.test;


/**
 * 1.以面向对象的思维去改造mybatis手写框架 2.将手写的mybatis的代码封装一个通用的框架（java工程）给程序员使用
 *
 * @author 灭霸詹
 *
 */

public class MybatisV3 {

}

