package com.kkb.core.executor;

public interface CachingExecutor extends Executor{
}
