package com.kkb.core.handler;

public interface ParameterHandler {
}
