package com.kkb.core.handler;

public class PreparedStatementHandler implements StatementHandler{
}
