package com.kkb.core.handler;

public class SimpleStatementHandler implements StatementHandler{
}
