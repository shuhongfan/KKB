package com.kkb.spring.test.v18;

/**
 * 使用面向对象思维和配置文件的方式去实现容器化管理Bean
 */
public class TestSpringV1803 {


}
