package com.kkb.core.handler;

public class DefaultResuiltSetHandler implements ResultSetHandler{
}
