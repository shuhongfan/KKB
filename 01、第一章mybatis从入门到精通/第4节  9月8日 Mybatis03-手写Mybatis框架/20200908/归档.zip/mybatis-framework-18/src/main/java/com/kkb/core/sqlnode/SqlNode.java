package com.kkb.core.sqlnode;

public interface SqlNode {
    void apply(DynamicContext context);
}
