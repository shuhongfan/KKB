package com.kkb.core.executor;

public abstract class BaseExecutor implements Executor{
}
