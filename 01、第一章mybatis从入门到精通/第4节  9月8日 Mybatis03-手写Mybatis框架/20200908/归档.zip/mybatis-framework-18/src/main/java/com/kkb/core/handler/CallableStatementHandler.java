package com.kkb.core.handler;

public class CallableStatementHandler implements StatementHandler{
}
