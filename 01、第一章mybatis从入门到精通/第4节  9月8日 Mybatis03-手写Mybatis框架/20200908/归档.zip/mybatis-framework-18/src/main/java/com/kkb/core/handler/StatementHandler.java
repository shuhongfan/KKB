package com.kkb.core.handler;

public interface StatementHandler {
}
