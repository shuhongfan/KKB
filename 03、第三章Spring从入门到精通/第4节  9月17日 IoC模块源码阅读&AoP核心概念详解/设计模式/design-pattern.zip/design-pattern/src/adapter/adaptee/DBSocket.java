package adapter.adaptee;

public interface DBSocket {

	void method();
}
